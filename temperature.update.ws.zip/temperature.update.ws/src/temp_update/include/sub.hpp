#ifndef TEMPERATURE_SUBSCRIBER_HPP
#define TEMPERATURE_SUBSCRIBER_HPP

#include <functional>
#include <memory>
#include "rclcpp/rclcpp.hpp"
#include "std_msgs/msg/float32.hpp"

class TemperatureSubscriber : public rclcpp::Node
{
public:
    TemperatureSubscriber();

private:
    void topic_callback(const std_msgs::msg::Float32 & msg) const;

    rclcpp::Subscription<std_msgs::msg::Float32>::SharedPtr subscription_;
};

#endif // TEMPERATURE_SUBSCRIBER_HPP
