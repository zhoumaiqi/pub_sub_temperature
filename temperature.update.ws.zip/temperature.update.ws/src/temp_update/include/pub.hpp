#ifndef TEMPERATURE_PUBLISHER_HPP
#define TEMPERATURE_PUBLISHER_HPP

#include <chrono>
#include <functional>
#include <memory>
#include <string>
#include "rclcpp/rclcpp.hpp"
#include "std_msgs/msg/float32.hpp"

class TemperaturePublisher : public rclcpp::Node
{
public:
    TemperaturePublisher();

private:
    void timer_callback();
    void temperature_update();

    rclcpp::TimerBase::SharedPtr timer_;
    rclcpp::Publisher<std_msgs::msg::Float32>::SharedPtr publisher_;
    std_msgs::msg::Float32 temperature_;
};

#endif // TEMPERATURE_PUBLISHER_HPP
