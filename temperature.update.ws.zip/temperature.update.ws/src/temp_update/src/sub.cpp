#include "sub.hpp"
#include <memory>
#include "rclcpp/rclcpp.hpp"
#include "std_msgs/msg/float32.hpp"

using std::placeholders::_1;

TemperatureSubscriber::TemperatureSubscriber()
: Node("temperature_subscriber")     
{
    subscription_ = this->create_subscription<std_msgs::msg::Float32>(
        "cmd_temperature", 10, std::bind(&TemperatureSubscriber::topic_callback, this, _1));
}

void TemperatureSubscriber::topic_callback(const std_msgs::msg::Float32 & msg) const
{
    float celsius = (msg.data - 32) * 5.0 / 9.0;
    RCLCPP_INFO(this->get_logger(), "Listening: celsius='%f'", celsius);
}

int main(int argc, char * argv[])
{
    rclcpp::init(argc, argv);
    rclcpp::spin(std::make_shared<TemperatureSubscriber>());
    rclcpp::shutdown();
    return 0;
}
