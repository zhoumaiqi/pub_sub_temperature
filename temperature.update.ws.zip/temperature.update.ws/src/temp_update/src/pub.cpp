#include "pub.hpp"
#include <chrono>
#include <memory>
#include <string>
#include <iostream>

using namespace std::chrono_literals;

TemperaturePublisher::TemperaturePublisher()
: Node("temperature_publisher")  
{
    publisher_ = this->create_publisher<std_msgs::msg::Float32>("cmd_temperature", 10);
    timer_ = this->create_wall_timer(1000ms, std::bind(&TemperaturePublisher::timer_callback, this));
}

void TemperaturePublisher::timer_callback()
{
    std_msgs::msg::Float32 message;
    message.data = temperature_.data;
    RCLCPP_INFO(this->get_logger(), "Publishing: fahrenheit='%f'", message.data);
    publisher_->publish(message);
    temperature_update();
}

void TemperaturePublisher::temperature_update()
{
    temperature_.data += 1.0;
}

int main(int argc, char * argv[])
{
    rclcpp::init(argc, argv);
    rclcpp::spin(std::make_shared<TemperaturePublisher>());
    rclcpp::shutdown();
    return 0;
}
