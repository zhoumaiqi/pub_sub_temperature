#include <chrono>
#include <functional>
#include <memory>
#include <string>
#include<iostream>
#include "rclcpp/rclcpp.hpp"
#include"std_msgs/msg/float32.hpp"

using namespace std::chrono_literals;

class TemperaturePublisher : public rclcpp::Node
{
  public:
    TemperaturePublisher()
    : Node("temperature_publisher")  
    {
      publisher_ = this->create_publisher<std_msgs::msg::Float32>("cmd_temperature",10);
      timer_ = this->create_wall_timer(1000ms, std::bind(&TemperaturePublisher::timer_callback, this));
    }

  private:
    void timer_callback()
    {
      std_msgs::msg::Float32 message;
      message.data = temperature_.data;
      RCLCPP_INFO(this->get_logger(),"Publishing:fahrenheit ='%f'",message.data);
      publisher_->publish(message);
      temperature_update();
    }
    void temperature_update()
    {
      temperature_.data+=1.0;
    }
    rclcpp::TimerBase::SharedPtr timer_;
    rclcpp::Publisher<std_msgs::msg::Float32>::SharedPtr publisher_;
    std_msgs::msg::Float32 temperature_;
};

int main(int argc, char * argv[])
{
  rclcpp::init(argc, argv);
  rclcpp::spin(std::make_shared<TemperaturePublisher>());
  rclcpp::shutdown();
  return 0;
}